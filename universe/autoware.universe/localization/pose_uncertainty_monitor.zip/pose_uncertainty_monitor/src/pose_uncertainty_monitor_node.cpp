#include "pose_uncertainty_monitor/pose_uncertainty_monitor_node.hpp"

#include <numeric>

namespace pose_uncertainty_monitor
{

PoseUncertaintyMonitorNode::PoseUncertaintyMonitorNode(const rclcpp::NodeOptions & options)
: Node("pose_uncertainty_monitor", options)
{
  // Parameters
  const auto input_pose_with_cov_topic = declare_parameter<std::string>("input_pose_with_cov_topic");
  const auto output_score_topic = declare_parameter<std::string>("output_score_topic");
  const auto output_uncertainty_vector_topic = declare_parameter<std::string>(
    "output_uncertainty_vector_topic", "/localization/diagnostics/uncertainty_vector");
  const auto output_uncertainty_score_topic = declare_parameter<std::string>(
    "output_uncertainty_score_topic", "/localization/diagnostics/uncertainty_score");

  // Subscriber
  sub_pose_with_cov_ = create_subscription<geometry_msgs::msg::PoseWithCovarianceStamped>(
    input_pose_with_cov_topic, rclcpp::QoS{1},
    std::bind(&PoseUncertaintyMonitorNode::on_pose_with_cov, this, std::placeholders::_1));

  // Publishers
  pub_health_score_ = create_publisher<tier4_debug_msgs::msg::Float64Stamped>(output_score_topic, rclcpp::QoS{1});
  pub_uncertainty_vector_ = create_publisher<autoware_localization_msgs::msg::PoseUncertaintyVector>(
    output_uncertainty_vector_topic, rclcpp::QoS{1});
  pub_uncertainty_score_ = create_publisher<autoware_localization_msgs::msg::PoseUncertaintyScore>(
    output_uncertainty_score_topic, rclcpp::QoS{1});
}

void PoseUncertaintyMonitorNode::on_pose_with_cov(const geometry_msgs::msg::PoseWithCovarianceStamped::ConstSharedPtr msg)
{
  // Extract variance values from the 6x6 covariance matrix
  // Covariance matrix is stored as a 36-element 1D array in row-major order
  // Diagonal indices: 0(X), 7(Y), 14(Z), 21(Roll), 28(Pitch), 35(Yaw)
  const double var_x = msg->pose.covariance[0];    // cov(x, x)
  const double var_y = msg->pose.covariance[7];    // cov(y, y)
  const double var_z = msg->pose.covariance[14];   // cov(z, z)
  const double var_yaw = msg->pose.covariance[35]; // cov(yaw, yaw)

  // Calculate standard deviations (sqrt of variance)
  const double std_x = std::sqrt(var_x);
  const double std_y = std::sqrt(var_y);
  const double std_z = std::sqrt(var_z);
  const double std_yaw = std::sqrt(var_yaw);

  // Publish uncertainty vector (standard deviations)
  autoware_localization_msgs::msg::PoseUncertaintyVector uncertainty_vector_msg;
  uncertainty_vector_msg.header = msg->header;
  uncertainty_vector_msg.std_x = std_x;
  uncertainty_vector_msg.std_y = std_y;
  uncertainty_vector_msg.std_z = std_z;
  uncertainty_vector_msg.std_yaw = std_yaw;
  pub_uncertainty_vector_->publish(uncertainty_vector_msg);

  // Publish uncertainty score (individual variances for validation)
  autoware_localization_msgs::msg::PoseUncertaintyScore uncertainty_score_msg;
  uncertainty_score_msg.header = msg->header;
  uncertainty_score_msg.score_x = var_x;
  uncertainty_score_msg.score_y = var_y;
  uncertainty_score_msg.score_z = var_z;
  uncertainty_score_msg.score_yaw = var_yaw;

  // Calculate total score (trace of position and orientation covariances)
  const double trace = var_x + var_y + var_z +
                       msg->pose.covariance[21] + msg->pose.covariance[28] + var_yaw;
  uncertainty_score_msg.score_total = trace;
  pub_uncertainty_score_->publish(uncertainty_score_msg);

  // Publish legacy health score (backward compatibility)
  tier4_debug_msgs::msg::Float64Stamped score_msg;
  score_msg.stamp = msg->header.stamp;
  score_msg.data = trace;
  pub_health_score_->publish(score_msg);
}

}  // namespace pose_uncertainty_monitor

#include "rclcpp_components/register_node_macro.hpp"
RCLCPP_COMPONENTS_REGISTER_NODE(pose_uncertainty_monitor::PoseUncertaintyMonitorNode)
